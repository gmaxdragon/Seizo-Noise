# Seizo Noise v2.1 — next engineering handoff

Saved October 23, 2026 Pacific. **Do not order / submit Gerbers yet.** This is the v2.1 through-hole 5V analog audio board, NOT the old v1 bare ESP32/12V project; **do not use old BOM files.**

## What the assistant completed

- Manufacturer and schematic review: 14 components, 29 electrical pad-net connections, eight nets, 85×60mm dual copper, four M3 holes.
- Corrected critical RV1 footprint metal tab positions from **10mm to 8.2mm center-to-center**, increased each metal mounting PTH bore to3.3mm with0.65mm ring. Repositioned RV1 center to **(78,26)mm** to expose shaft past x85 edge; actual knob/endcase not physically verified.
- Moved J4 stereo AUX jack center to (30,6)mm for cable entry; increased three plated insertion slots to1.1x2.2mm with ~0.3mm minimum nominal annular copper. Verified manufacturer pin1 sleeve/pin2 tip/pin3 ring versus custom pad S/T/R mapping.
- Rerouted from scratch (not overlaid duplicate traces), refilled copper zones and regenerated final output. Independent KiCad10/ERC/DRC and XML pad-net comparison verified. Exact results in `validation/ERC_independent.rpt`, `validation/DRC_independent.rpt`, and `validation/INDEPENDENT_RELEASE_AUDIT.json`.
- Exported fabrication preview in `fabrication/DRAFT_ONLY/` with 31 PTH (three jack slots and two pot mount holes) plus four NPTH, **not an approved order**. Rendered current 3D preview at `docs/plots/Seizo_Noise_v2_1_CAD_RENDER.png`; body images for controls are approximations.
- Newly identified purchasable C2 ceramic: KEMET `C052C104K5R5TA` 100nF 50V X7R 5.08mm lead spacing; product documentation and all other component research under `docs/research/ENGINEERING_RELEASE_AUDIT.md`.

## Needed from the operator or physical bench

1. Check the **actual power adapter**: output explicitly **5V DC / 1A**, correct barrel plug/polarity, regulated 5V under a load; user already owns barrel-to-screw adapter but its exact mating geometry is not confirmed. A separate Pi supply is mandatory until USB-power headroom and ground noise are measured.
2. Confirm **Bourns PTV09A-2020F-A103 actual tab insertion** into large 3.3mm PTH mounting holes, shaft projection and knob hub/case wall fit; side-mount version is bushingless. This is the main remaining mechanical risk. Prototype board may be needed before certainty; do not promise perfect fit based on DRC.
3. Confirm **SJ1-3533NG AUX barrel case clearance** and plated insertion slots; physically trial fit and look for jack plug full insertion.
4. Confirm Pi can host a USB mic with cameras/controllers attached; test **actual ALSA recording** and speech integration, not only browser speech demo. No automatic motion.
5. Choose actual speaker 4ohm/3W and PAM8302, place separately in case and use short four-wire harness from J3 plus two speaker wires. Verify all wiring and measured output from charger.
6. Rebuild a v2.1-only BOM including cables, case, mounting, amp, mic, speaker, PCB, taxes, shipping and tariff; check $65 target from real cart before buying.

## Acceptance before final order

Zero native ERC errors/warnings and DRC violations in clean project, pin/net parity, real manufacturer SKU mapping, mechanical fit/clearance, fabrication portal hole/slot rendering, delivered price. Hardware working tests follow production: power-off continuity & polarity, current-limited 5V first power, voltage measurement, audible playback and microphone recording, clipping/noise/thermal and cable-strain tests. A 3D render, ERC or DRC cannot prove any of these physical tests.
