#!/usr/bin/env python3.12
"""Conservative two-layer manual-equivalent A* routing on the B.Cu of a hand-solder v2 carrier.
Never changes component positions, pads, or schematic; fails closed if no obstacle-safe path exists.
"""
import pcbnew as pcb,heapq,math
from pathlib import Path
P=Path(__file__).resolve().parent.parent/'Seizo_Noise_v2.kicad_pcb'
B=pcb.LoadBoard(str(P))
step=0.25
W,H=round(85/step),round(60/step)
fps={f.GetReference():f for f in B.GetFootprints()}
pads={}
for ref,fp in fps.items():
 for pad in fp.Pads():
  if pad.GetNumber():pads[(ref,pad.GetNumber())]=pad
nets={n.GetNetname():n for n in B.GetNetInfo().NetsByNetcode().values() if n}
print('nets',list(nets))

# Edge, all plated and non-plated holes, and all different-net copper are obstacles.
def mm(n):return pcb.ToMM(n)
def pt(p):return mm(p.GetPosition().x),mm(p.GetPosition().y)
def cells(x,y,r):
 lo=max(0,int(math.floor((x-r)/step)));hi=min(W,int(math.ceil((x+r)/step)))
 yo=max(0,int(math.floor((y-r)/step)));yh=min(H,int(math.ceil((y+r)/step)))
 rr=(r+0.04)**2
 for i in range(lo,hi+1):
  dx=(i*step-x)**2
  for j in range(yo,yh+1):
   if dx+(j*step-y)**2<=rr:yield i,j

def obstacles(for_net,width,clearance=0.31):
 obs=set()
 radius=width/2+clearance
 for ref,fp in fps.items():
  for p in fp.Pads():
   if p.GetNetname()==for_net and p.GetNumber(): continue
   x,y=pt(p); b=p.GetBoundingBox()
   szx=mm(b.GetWidth());szy=mm(b.GetHeight())
   r=max(szx,szy)/2+radius
   obs.update(cells(x,y,r))
 for tr in B.GetTracks():
  if tr.GetLayer()!=pcb.B_Cu or tr.GetNetname()==for_net:continue
  a=(mm(tr.GetStart().x),mm(tr.GetStart().y));b=(mm(tr.GetEnd().x),mm(tr.GetEnd().y))
  length=math.dist(a,b)
  steps=max(1,int(math.ceil(length/(step/2))))
  r=width/2+mm(tr.GetWidth())/2+clearance
  for k in range(steps+1):
   frac=k/steps
   obs.update(cells(a[0]+frac*(b[0]-a[0]),a[1]+frac*(b[1]-a[1]),r))
 return obs

DIRS=[(1,0,1),(-1,0,1),(0,1,1),(0,-1,1),(1,1,math.sqrt(2)),(1,-1,math.sqrt(2)),(-1,1,math.sqrt(2)),(-1,-1,math.sqrt(2))]
def search(a,b,obs):
 sx,sy=a;tx,ty=b
 start=(round(sx/step),round(sy/step))
 goal=(round(tx/step),round(ty/step))
 # Never turn a different-net collision into a start-pad exception.
 if start in obs:raise ValueError(f'start pad blocked near {a}')
 if goal in obs:raise ValueError(f'goal pad blocked near {b}')
 pq=[];ct=0;heapq.heappush(pq,(math.hypot(goal[0]-start[0],goal[1]-start[1]),ct,start))
 dist={start:0};parent={};visited=set()
 while pq:
  _,_,pos=heapq.heappop(pq)
  if pos in visited:continue
  visited.add(pos)
  if pos==goal:
   path=[pos]
   while pos!=start:
    pos=parent[pos];path.append(pos)
   path.reverse()
   return [(p[0]*step,p[1]*step) for p in path],len(visited)
  px,py=pos
  for dx,dy,w in DIRS:
   q=(px+dx,py+dy)
   if q in visited or q in obs or not(2<=q[0]<=W-2 and 2<=q[1]<=H-2):continue
   if dx and dy and ((px+dx,py) in obs or (px,py+dy) in obs):continue
   ng=dist[pos]+w
   if ng>=dist.get(q,1e50):continue
   dist[q]=ng;parent[q]=pos
   h=math.hypot(goal[0]-q[0],goal[1]-q[1])
   ct+=1
   heapq.heappush(pq,(ng+h,ct,q))
 raise ValueError(f'No path from {a} to {b}, explored {len(visited)} cells')

def compress(points):
 res=[]
 for p in points:
  if res and math.dist(p,res[-1])<0.0001:continue
  while len(res)>=2:
   a,b=res[-2:]
   u=(b[0]-a[0],b[1]-a[1]);v=(p[0]-b[0],p[1]-b[1])
   if abs(u[0]*v[1]-u[1]*v[0])<1e-4 and u[0]*v[0]+u[1]*v[1]>=-1e-8:res.pop()
   else:break
  res.append(p)
 return res

def route(name,connections,width):
 net=nets[name]
 for u,v in zip(connections,connections[1:]):
  a=pt(pads[u]);b=pt(pads[v])
  ob=obstacles(name,width)
  path,expanded=search(a,b,ob)
  arr=compress([a]+path+[b]);l=0
  for p,q in zip(arr,arr[1:]):
   if math.dist(p,q)<.03:continue
   t=pcb.PCB_TRACK(B);t.SetStart(pcb.VECTOR2I(pcb.FromMM(p[0]),pcb.FromMM(p[1])));t.SetEnd(pcb.VECTOR2I(pcb.FromMM(q[0]),pcb.FromMM(q[1])));t.SetWidth(pcb.FromMM(width));t.SetLayer(pcb.B_Cu);t.SetNet(net);B.Add(t);l+=math.dist(p,q)
  print(f'ROUTED {name} {u}->{v} {len(arr)} vertices {l:.1f}mm, search {expanded}')

# Join from the jack side to the amplifier, route power last through unobstructed lower region.
ROUTES=[
 ('Net-(J4-PadT)',[('J4','T'),('R1','1')],.35),
 ('Net-(J4-PadR)',[('J4','R'),('R2','2')],.35),
 ('/AUDIO_MIX',[('R1','2'),('R2','1'),('RV1','3')],.35),
 ('/AMP_IN',[('RV1','2'),('TP3','1'),('R3','1'),('J3','3')],.35),
 ('Net-(J1-Pin_1)',[('J1','1'),('F1','1')],.85),
 ('Net-(D1-A)',[('F1','2'),('D1','2')],.85),
 ('/+5V_AUDIO',[('D1','1'),('C1','1'),('C2','1'),('TP1','1'),('J3','1')],.8),
]
for net,path,width in ROUTES:route(net,path,width)
pcb.SaveBoard(str(P),B)
print('TRACKS',len(B.GetTracks()),'saved',P)
