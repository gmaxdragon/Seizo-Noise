#!/usr/bin/env python3.12
# Run with KiCad 10 Python/pcbnew against this project folder; requires installed KiCad bindings.
import pcbnew as pcb
import xml.etree.ElementTree as ET
from pathlib import Path

DIR=Path(__file__).resolve().parent.parent
P=DIR/'Seizo_Noise_v2.kicad_pcb'
T=ET.parse(DIR/'v2.xml').getroot()
components=T.find('components')
comps={x.get('ref'):x for x in components.findall('comp')}
expected={'C1','C2','D1','F1','J1','J3','J4','R1','R2','R3','RV1','TP1','TP2','TP3'}
assert set(comps)==expected,(set(comps),expected)
NETS={}
for net in T.find('nets').findall('net'):
 NETS[net.get('name')]=[(n.get('ref'),n.get('pin')) for n in net.findall('node')]
assert len(NETS)==8,NETS
assert set(NETS['/+5V_AUDIO'])=={('C1','1'),('C2','1'),('D1','1'),('J3','1'),('TP1','1')}
B=pcb.BOARD()
B.SetCopperLayerCount(2)
placements={
 'J4':(30,6,0),  # 3.5mm jack points toward upper PCB edge
 'RV1':(78,26,0),  # side-mounted volume pot; nominal shaft tip extends ~9.8 mm beyond x=85 board edge
 'J1':(13,49,0), # fused 5V input terminal, lower left
 'F1':(26,46,0),
 'D1':(46.16,46,180), # pin2 at x36, pin1 at x46.16
 'C1':(54,46,0),
 'C2':(69,46,0),
 'R1':(44,21,0),
 'R2':(51.62,32,180),
 'R3':(55,38,0),
 'J3':(79,35,0),
 'TP1':(70,52,0),
 'TP2':(66,56,0),
 'TP3':(70,34,0),
}
lookup={}
for ref,c in comps.items():
 fpid=c.findtext('footprint')
 assert fpid.startswith('Seizo_Noise_v2:')
 lib,name=fpid.split(':',1)
 fp=pcb.FootprintLoad(str(DIR/(lib+'.pretty')),name)
 assert fp,ref
 x,y,angle=placements[ref]
 fp.SetReference(ref)
 fp.SetValue(c.findtext('value') or '')
 fp.SetPosition(pcb.VECTOR2I(pcb.FromMM(x),pcb.FromMM(y)))
 if angle:fp.SetOrientationDegrees(angle)
 fp.SetFPIDAsString(fpid)
 fp.SetLibDescription(c.findtext('description') or '')
 for field in fp.GetFields():
  if field.GetName()=='Description': field.SetText(c.findtext('description') or '')
 for field in fp.GetFields():
  if field.GetName()=='Datasheet' and ref=='RV1': field.SetText('')
 fp.SetPath(pcb.KIID_PATH('/'+c.findtext('tstamps')))
 B.Add(fp)
 lookup[ref]=fp
 # All custom exact board silkscreen text is independent of fab/3d.
 print(ref,'footprint',fpid,'path',fp.GetPath().AsString())

# design nets and bind reference + numbered pin pads
netmap={}
for name, connections in NETS.items():
 ni=pcb.NETINFO_ITEM(B,name)
 B.Add(ni)
 netmap[name]=ni
 for ref,padnum in connections:
  pads=[p for p in lookup[ref].Pads() if p.GetNumber()==padnum]
  if len(pads)!=1:raise ValueError(f'{ref}:{padnum} missing/duplicated in footprint: {pads}')
  pads[0].SetNet(ni)
# Non-electric mounting pads carry no net

# Board outline; 85 x 60mm fits 100x100mm prototype price tier
shape=pcb.PCB_SHAPE(B);shape.SetShape(pcb.SHAPE_T_RECT);shape.SetStart(pcb.VECTOR2I(0,0));shape.SetEnd(pcb.VECTOR2I(pcb.FromMM(85),pcb.FromMM(60)));shape.SetLayer(pcb.Edge_Cuts);shape.SetWidth(pcb.FromMM(.05));B.Add(shape)
for x,y,i in [(5,5,1),(80,5,2),(5,55,3),(80,55,4)]:
 fp=pcb.FootprintLoad(str(DIR/'Seizo_Noise_v2.pretty'),'MountingHole_M3_NPTH')
 assert fp
 fp.SetReference('H'+str(i));fp.SetBoardOnly(True);fp.SetExcludedFromBOM(True);fp.SetExcludedFromPosFiles(True);fp.SetFPIDAsString('Seizo_Noise_v2:MountingHole_M3_NPTH')
 fp.SetPosition(pcb.VECTOR2I(pcb.FromMM(x),pcb.FromMM(y)))
 B.Add(fp)

def text(x,y,t,size=1,thickness=.18,angle=0,layer=pcb.F_SilkS):
 tx=pcb.PCB_TEXT(B);tx.SetText(t);tx.SetPosition(pcb.VECTOR2I(pcb.FromMM(x),pcb.FromMM(y)))
 tx.SetTextSize(pcb.VECTOR2I(pcb.FromMM(size),pcb.FromMM(size)))
 tx.SetTextThickness(pcb.FromMM(thickness));tx.SetLayer(layer)
 tx.SetTextAngle(pcb.EDA_ANGLE(angle,pcb.DEGREES_T));tx.SetMirrored(layer==pcb.B_SilkS);B.Add(tx)
 return tx
# Silk is useful for assembly but avoid writing over contact pads or component bodies
text(40,56.5,'SEIZO NOISE  /  V2.1',1.0,.17)
text(13.5,41,'5V DC',.9,.15)
text(42,7.5,'AUX IN',.95,.16)
text(62,15,'VOLUME',.85,.15)
text(79,48.7,'PAM8302',.8,.14)
text(83,35,'5V',.8,.14)
text(83,37.54,'GND',.8,.14)
text(83,40.08,'A+',.8,.14)
text(83,42.62,'A-',.8,.14)
text(13,54,'5V+',.8,.14)
text(18.08,54,'GND',.8,.14)
text(50,40,'C1 +',.8,.14)
text(46,53.6,'D1 K',.85,.14)
text(78,52.5,'+5V',.85,.14)
text(61,54,'GND',.85,.14)
text(71,38,'AMP TP',.8,.14)
text(44,12,'PI HEADPHONES',.8,.14,layer=pcb.B_SilkS)
text(43,58,'SEIZO / AUDIO INTERFACE',.85,.14,layer=pcb.B_SilkS)
text(40,4.5,'SPEAKER OUTPUT ON AMP MODULE',.8,.14,layer=pcb.B_SilkS)
text(72,13,'J3: 1 VIN / 2 GND / 3 A+ / 4 A-',.8,.14,layer=pcb.B_SilkS)
# The audio test point is labelled away from potentiometer courtyard.
ref3=lookup['TP3'].Reference()
ref3.SetPosition(pcb.VECTOR2I(pcb.FromMM(66.0),pcb.FromMM(34.0)))
# continuous ground pour on F.Cu, THT pads connect both sides
zone=pcb.ZONE(B);zone.SetLayer(pcb.F_Cu)
zone.SetNet(netmap['GND'])
zone.SetLocalClearance(pcb.FromMM(.3))
zone.SetThermalReliefGap(pcb.FromMM(.3))
zone.SetThermalReliefSpokeWidth(pcb.FromMM(.45))
zone.SetPadConnection(pcb.ZONE_CONNECTION_THERMAL)
zone.Outline().NewOutline()
for x,y in [(0.8,0.8),(84.2,0.8),(84.2,59.2),(0.8,59.2)]:
 zone.Outline().Append(pcb.FromMM(x),pcb.FromMM(y))
B.Add(zone)

pcb.SaveBoard(str(P),B)
print('Saved',P,'nets',len(NETS),'footprints',len(B.GetFootprints()),'pads',sum(1 for f in B.GetFootprints() for p in f.Pads()))
print('Connections',NETS)
